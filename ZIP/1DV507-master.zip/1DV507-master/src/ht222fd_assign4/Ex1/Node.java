package ht222fd_assign4.Ex1;

/**
 * Created by hteva on 07/03/2017.
 */
public class Node <T>{
    T value;
    Node next;

    public Node(T element){
        this.value = element;
    }

}