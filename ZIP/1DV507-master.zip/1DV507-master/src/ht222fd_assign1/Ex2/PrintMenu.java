package ht222fd_assign1.Ex2;

/*CLASS PRINTMENU:
I'm improving in my lazyness!
* */
public  class PrintMenu {
    public static void main(){
        System.out.println("==============================");
        System.out.println("|       MENU SELECTION       |");
        System.out.println("==============================");
        System.out.println("| Options:                   |");
        System.out.println("|        1. Embark Vehicle   |");
        System.out.println("|        2. Embark Passenger |");
        System.out.println("|        3. Check Ferry      |");
        System.out.println("|        4. Disembark        |");
        System.out.println("|        5. Exit             |");
        System.out.println("==============================");
    }
    public static void vehicles(){
        System.out.println("==============================");
        System.out.println("|       MENU VEHICLES        |");
        System.out.println("==============================");
        System.out.println("| Options:                   |");
        System.out.println("|        1. Bike             |");
        System.out.println("|        2. Car              |");
        System.out.println("|        3. Bus              |");
        System.out.println("|        4. Lorry            |");
        System.out.println("|        5. Exit             |");
        System.out.println("==============================");
    }


}
