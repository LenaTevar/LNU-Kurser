package ht222fd_assign2.Ex1;

/**
 * Dummy class to test LinkedQueue
 */
public class Duck {
    private String name;

    public Duck(String n){
        this.name = n;
    }
}
