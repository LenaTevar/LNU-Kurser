# LanguageAndLogic
Language and Logic LNU

## Assignment 1 
Automata
Regular expressions

## Assignment 2
Turing Machines
Parsers

## Assignment 3
Logic
