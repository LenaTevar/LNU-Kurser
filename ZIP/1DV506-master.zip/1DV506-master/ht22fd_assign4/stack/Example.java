package ht22fd_assign4.stack;
/*Example:
 * Keeping this as simple as possible
 * because it's just a test.
 * */
public class Example {
    private int id;

    public Example(int n){
        setId(n);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}