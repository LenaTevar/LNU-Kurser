package ht222fd_assign1;

/**
 * Created by hteva on 25/10/2016.
 */
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
