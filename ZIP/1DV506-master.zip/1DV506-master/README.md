# 1DV506
Linnéuniversitetet - Java part 1
Assigments from Java course, "Software Technology" program. 
