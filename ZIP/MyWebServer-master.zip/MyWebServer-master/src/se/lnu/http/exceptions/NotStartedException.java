package se.lnu.http.exceptions;

public class NotStartedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6733868884526050283L;

}
