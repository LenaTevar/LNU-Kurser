package se.lnu.http.exceptions;

public class InvalidPortException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3615635556121136L;

	public InvalidPortException(String string) {
		super(string);
	}

	

}
