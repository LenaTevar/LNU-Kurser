MyWebServer
===========

A Simple to use java - webserver
